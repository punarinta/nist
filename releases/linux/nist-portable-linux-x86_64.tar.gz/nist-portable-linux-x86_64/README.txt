nist - Portable Linux Build
============================

This is a portable build of nist that includes all SDL2 libraries.
No installation required - just extract and run!

RUNNING
-------
Simply execute the 'nist' script:

    ./nist

INSTALLATION (Optional)
-----------------------
To install system-wide, copy the entire directory to a location like
/opt/nist and create a symlink in /usr/local/bin:

    sudo cp -r nist-portable-linux-x86_64 /opt/nist
    sudo ln -s /opt/nist/nist /usr/local/bin/nist

Or install to your home directory:

    mkdir -p ~/.local/share/nist
    cp -r * ~/.local/share/nist/
    ln -s ~/.local/share/nist/nist ~/.local/bin/nist

CONTENTS
--------
- nist          : Launcher script
- nist-bin      : Main executable
- lib/          : Bundled SDL2 libraries
- README.txt    : This file

REQUIREMENTS
------------
This build should work on most modern x86_64 Linux distributions.
Minimum requirements:
- glibc 2.31 or newer
- X11 or Wayland display server

TROUBLESHOOTING
---------------
If you encounter issues, try running with verbose output:

    LD_DEBUG=libs ./nist

For support, visit: https://github.com/yourusername/nist/issues
