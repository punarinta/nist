# Nist Terminal Emulator - Windows Release

A modern terminal emulator with support for multiple tabs and split panes.

## What's Included

- `nist.exe` - The main terminal emulator executable
- `SDL2.dll` - Required SDL2 graphics library
- `SDL2_ttf.dll` - Required SDL2 font rendering library

## Requirements

- Windows 10 or later (64-bit)
- The SDL2 DLLs must be in the same directory as `nist.exe`

## Installation

1. Extract all files from the zip archive to a folder of your choice
2. Ensure `SDL2.dll` and `SDL2_ttf.dll` are in the same folder as `nist.exe`
3. Double-click `nist.exe` to run

Optionally, you can:
- Add the folder to your PATH to run `nist` from anywhere
- Create a desktop shortcut to `nist.exe`

## Usage

### Basic Controls

- **Ctrl+Shift+T** - New tab
- **Ctrl+Shift+W** - Close current tab
- **Ctrl+Shift+E** - Split pane horizontally
- **Ctrl+Shift+O** - Split pane vertically
- **Ctrl+Tab** - Next tab
- **Ctrl+Shift+Tab** - Previous tab
- **Ctrl+Shift+C** - Copy selected text
- **Ctrl+Shift+V** - Paste

### Features

- Multiple tabs support
- Split pane layouts (horizontal and vertical)
- Cross-platform PTY (pseudo-terminal) implementation
- Full ANSI escape sequence support
- Modern GPU-accelerated rendering

## Configuration

On first run, Nist will create a configuration directory at:
```
%APPDATA%\nist\
```

State files are stored at:
```
%USERPROFILE%\.config\nist\state.json
```

## Shell Support

Nist automatically detects and uses the system shell:
- PowerShell (default on Windows 10+)
- Command Prompt (cmd.exe)
- WSL (Windows Subsystem for Linux) if available

## Troubleshooting

### "Application failed to start" or DLL errors
- Ensure `SDL2.dll` and `SDL2_ttf.dll` are in the same folder as `nist.exe`
- Try downloading the latest Visual C++ Redistributable from Microsoft

### Terminal doesn't start or crashes
- Check Windows Event Viewer for error details
- Make sure you're running on Windows 10 or later

### Fonts not rendering correctly
- Ensure `SDL2_ttf.dll` is present and not corrupted
- Try reinstalling by extracting fresh files from the zip

## About

Nist is a cross-platform terminal emulator built with:
- Rust programming language
- SDL2 for graphics and input
- portable-pty for Windows ConPTY support
- egui for the user interface

This Windows build is cross-compiled from Linux using MinGW-w64.

## License & Source Code

For source code, bug reports, and contributions, visit:
https://github.com/nisdos/nt

## Notes

- This is a native Windows application using ConPTY for terminal emulation
- GPU acceleration is used for rendering, so a graphics driver is required
- The binary is statically linked where possible to minimize dependencies